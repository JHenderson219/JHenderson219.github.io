A Pen created at CodePen.io. You can find this one at http://codepen.io/JHenderson219/pen/PGwRpx.

 Free Code Camp Portfolio Page project